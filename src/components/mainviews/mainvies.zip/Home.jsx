import React from 'react';
import Image from 'react-bootstrap/Image'
import UnicornCake from '../../img/cakes/pastelr.jpg';
import '../../styles/mainViews/Home.css';
import { Link } from "react-router-dom";

import BgVector from '../pieces/BgVector';
import SocialMedia from '../pieces/SocialMedia';
import CircleLogo from '../pieces/CircleLogo';
import BackButton from '../pieces/BackButton';

function Home () {
    return (
        <div className='HomeContainer'>
            <BgVector />
            <div className='RectangleHome'>
                <CircleLogo />
                <div className='UnicornContainer'>
                    <Image src={UnicornCake} alt='TortasUnicornio' className='UnicornCake'/>
                </div>
                <SocialMedia />

                <Link to="/Menu" className='LinkMenu'>
                    <BackButton Text='Explorar' />
                </Link>
                
            </div>
        </div>
    )
}

export default Home;